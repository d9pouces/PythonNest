# -*- coding: utf-8 -*-
"""
This package contains Django stuff related to the global project (not only to a single application):

  * settings
  * middlewares
  * WSGI application
  * root urls

"""
__author__ = "flanker"
